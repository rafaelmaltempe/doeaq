/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author rafael
 */
import java.sql.SQLException;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import java.util.List;
  
import conexao.IncluirProduto;
import codigos.CadastroProduto;

@ManagedBean(name="IncluirMB")
public class ProdutoManagedBean {
    
    private CadastroProduto cadastro = new CadastroProduto();
    
      
     public String cadastraProduto() throws SQLException {
           
                IncluirProduto con = new IncluirProduto();
                 
                 
                if (con.insertProduto(cadastro)) {
                     FacesContext.getCurrentInstance().addMessage(
                      null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                      "Sucesso!", "Usuário cadastrado com sucesso!"));
                } else {
                     FacesContext.getCurrentInstance().addMessage(
                        null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"Erro!", 
                        "Erro no cadastro de usuário!"));
  
                }
                con.closeConnection();
                
          return "";
     }
     
     
         public List<CadastroProduto> getProduto() throws SQLException {
  
          IncluirProduto con = new IncluirProduto();
          List<CadastroProduto> listaProduto = con.listProdutos();
      
          return listaProduto;
     } 
     
    public CadastroProduto getCadastro() {
        return cadastro;
    }

    public void setCadastro(CadastroProduto cadastro) {
        this.cadastro = cadastro;
    }
    
}
