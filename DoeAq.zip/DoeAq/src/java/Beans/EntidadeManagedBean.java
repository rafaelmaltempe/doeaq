/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author rafael
 */
import codigos.CadastroBeneficente;
import java.sql.SQLException;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import java.util.List;
  
import conexao.IncluirEntidade;
import codigos.CadastroBeneficente;

@ManagedBean(name="IncluirEntMB")
public class EntidadeManagedBean {
    
    private CadastroBeneficente cadastro = new CadastroBeneficente();
    
      
     public String cadastraEntidade() throws SQLException {
           
                IncluirEntidade con = new IncluirEntidade();
                 
                 
                if (con.insertEntidade(cadastro)) {
                     FacesContext.getCurrentInstance().addMessage(
                      null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                      "Cadastro realizado com Sucesso!", "Usuário cadastrado com sucesso!"));
                } else {
                     FacesContext.getCurrentInstance().addMessage(
                        null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"Erro ao Cadastrar!", 
                        "Erro no cadastro de usuário!"));
  
                }
                con.closeConnection();
                
          return "";
     }
     
     
         public List<CadastroBeneficente> getBeneficente() throws SQLException {
  
          IncluirEntidade con = new IncluirEntidade();
          List<CadastroBeneficente> listaBeneficente = con.listBeneficente();
      
          return listaBeneficente;
     } 
     
    public CadastroBeneficente getCadastro() {
        return cadastro;
    }

    public void setCadastro(CadastroBeneficente cadastro) {
        this.cadastro = cadastro;
    }
    
}
