/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

/**
 *
 * @author rafael
 */

import java.sql.SQLException;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import java.util.List;
  
import conexao.IncluirVoluntario;
import codigos.CadastroVoluntario;

@ManagedBean(name="IncluirVolMB")
public class VoluntarioManagedBean {
    
    private CadastroVoluntario cadastro = new CadastroVoluntario();
    
      
     public String cadastraVoluntario() throws SQLException {
           
                IncluirVoluntario con = new IncluirVoluntario();
                 
                 
                if (con.insertVoluntario(cadastro)) {
                     FacesContext.getCurrentInstance().addMessage(
                      null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                      "Cadastro realizado com Sucesso!", "Usuário cadastrado com sucesso!"));
                } else {
                     FacesContext.getCurrentInstance().addMessage(
                        null, new FacesMessage(FacesMessage.SEVERITY_ERROR,"Erro ao Cadastrar!", 
                        "Erro no cadastro de usuário!"));
  
                }
                con.closeConnection();
                
          return "";
     }
     
     
         public List<CadastroVoluntario> getVoluntarios() throws SQLException {
  
          IncluirVoluntario con = new IncluirVoluntario();
          List<CadastroVoluntario> listaVoluntarios = con.listVoluntario();
      
          return listaVoluntarios;
     } 
     
    public CadastroVoluntario getCadastro() {
        return cadastro;
    }

    public void setCadastro(CadastroVoluntario cadastro) {
        this.cadastro = cadastro;
    }
    
}
