package codigos;


import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author rafael
 */
public class CadastroDoacao {
    
    private int id;
    private String entidade;
    private Date data_doacao;
    private String Produto;
    private int quantidade;
    private String retira_produtos;
    private String endereco_retirada;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEntidade() {
        return entidade;
    }

    public void setEntidade(String entidade) {
        this.entidade = entidade;
    }

    public Date getData_doacao() {
        return data_doacao;
    }

    public void setData_doacao(Date data_doacao) {
        this.data_doacao = data_doacao;
    }

    public String getProduto() {
        return Produto;
    }

    public void setProduto(String Produto) {
        this.Produto = Produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getRetira_produtos() {
        return retira_produtos;
    }

    public void setRetira_produtos(String retira_produtos) {
        this.retira_produtos = retira_produtos;
    }

    public String getEndereco_retirada() {
        return endereco_retirada;
    }

    public void setEndereco_retirada(String endereco_retirada) {
        this.endereco_retirada = endereco_retirada;
    }
    
}
