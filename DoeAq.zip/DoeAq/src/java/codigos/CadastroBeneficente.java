package codigos;

import java.util.Date;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author rafael
 */
public class CadastroBeneficente {
    
    private int id;
    private String nome;
    private String data;
    private String email;
    private String fone;
    private String endereco;
    private String senha;
    private String confirmSenha;
    private String cnpj;
    private String razao_social;
    private String info_entidade;
    private String aceita_voluntario;
    private String retira_doacao;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getConfirmSenha() {
        return confirmSenha;
    }

    public void setConfirmSenha(String confirmSenha) {
        this.confirmSenha = confirmSenha;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getRazao_social() {
        return razao_social;
    }

    public void setRazao_social(String razao_social) {
        this.razao_social = razao_social;
    }

    public String getInfo_entidade() {
        return info_entidade;
    }

    public void setInfo_entidade(String info_entidade) {
        this.info_entidade = info_entidade;
    }

    public String getAceita_voluntario() {
        return aceita_voluntario;
    }

    public void setAceita_voluntario(String aceita_voluntario) {
        this.aceita_voluntario = aceita_voluntario;
    }

    public String getRetira_doacao() {
        return retira_doacao;
    }

    public void setRetira_doacao(String retira_doacao) {
        this.retira_doacao = retira_doacao;
    }
    
}
