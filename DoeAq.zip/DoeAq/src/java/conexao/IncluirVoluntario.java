/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;

import codigos.CadastroBeneficente;
import codigos.CadastroVoluntario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rafael
 */
public class IncluirVoluntario {
 
     Connection con = null;
  
     public IncluirVoluntario() throws SQLException {
  
          try {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Conectado com sucesso...");
          } catch (ClassNotFoundException e) {
                // TODO Auto-generated catch block
              System.out.println("Problema de conexao: " + e);
                e.printStackTrace();
          }
  
          String url = "jdbc:mysql://localhost:3306/usuario";
          String user = "root";
          String password = "";
          con = DriverManager.getConnection(url, user, password);
     }
  
     public void closeConnection() throws SQLException {
  
          con.close();
     }

        public boolean insertVoluntario(CadastroVoluntario voluntario){
          Statement st = null;
          ResultSet rs = null;
  
          try {
                st = con.createStatement();
  
                PreparedStatement preparedStatement = con.prepareStatement("insert into voluntario(id, nome, data, cpfcnpj, email, telefone, endereco, cep, senha, permite_msg) values(?,?,?,?,?,?,?,?,?,?)");
                preparedStatement.setInt(1, voluntario.getId());
                preparedStatement.setString(2, voluntario.getNome());
                preparedStatement.setString(3, voluntario.getData());
                preparedStatement.setString(4, voluntario.getCpf_cpj());
                preparedStatement.setString(5, voluntario.getEmail());
                preparedStatement.setString(6, voluntario.getFone());
                preparedStatement.setString(7, voluntario.getEndereco());
                preparedStatement.setString(8, voluntario.getCep());
                preparedStatement.setString(9, voluntario.getSenha());
                preparedStatement.setString(10, voluntario.getMensagens());
        
                
                preparedStatement.execute();
                return true;
          } catch (SQLException ex) {
                Logger lgr = Logger.getLogger(IncluirVoluntario.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
                return false;
            }
        }
        
         //lista todos os usuarios cadastrados no banco de dados
     public List<CadastroVoluntario> listVoluntario() {
  
          ArrayList<CadastroVoluntario> lista = new ArrayList<CadastroVoluntario>();
  
          Statement st = null;
          ResultSet rs = null;
  
          try {
                st = con.createStatement();
                String sql = "select * from voluntario ";
               rs = st.executeQuery(sql);
  
                while (rs.next()) {
  
                     CadastroVoluntario cadVoluntario = new CadastroVoluntario();
                     cadVoluntario.setId(rs.getInt(1));
                     cadVoluntario.setNome(rs.getString(2));
                     cadVoluntario.setData(rs.getString(3));
                     cadVoluntario.setCpf_cpj(rs.getString(4));
                     cadVoluntario.setEmail(rs.getString(5));
                     cadVoluntario.setFone(rs.getString(6));
                     cadVoluntario.setEndereco(rs.getString(7));
                     cadVoluntario.setCep(rs.getString(8));
                     cadVoluntario.setSenha(rs.getString(9));                     
                     cadVoluntario.setMensagens(rs.getString(10));                     
                     

                     lista.add(cadVoluntario);
                }
  
          } catch (SQLException ex) {
                Logger lgr = Logger.getLogger(IncluirVoluntario.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
  
          } finally {
                try {
                     if (rs != null) {
                          rs.close();
                     }
                     if (st != null) {
                          st.close();
                     }
                     if (con != null) {
                          con.close();
                     }
  
                } catch (SQLException ex) {
                     Logger lgr = Logger.getLogger(IncluirVoluntario.class.getName());
                     lgr.log(Level.WARNING, ex.getMessage(), ex);
                }
          }
          return lista;
     }
}