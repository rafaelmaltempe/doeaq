/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;

import codigos.CadastroBeneficente;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rafael
 */
public class IncluirEntidade {
 
     Connection con = null;
  
     public IncluirEntidade() throws SQLException {
  
          try {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Conectado com sucesso...");
          } catch (ClassNotFoundException e) {
                // TODO Auto-generated catch block
              System.out.println("Problema de conexao: " + e);
                e.printStackTrace();
          }
  
          String url = "jdbc:mysql://localhost:3306/usuario";
          String user = "root";
          String password = "";
          con = DriverManager.getConnection(url, user, password);
     }
  
     public void closeConnection() throws SQLException {
  
          con.close();
     }

        public boolean insertEntidade(CadastroBeneficente beneficente){
          Statement st = null;
          ResultSet rs = null;
  
          try {
                st = con.createStatement();
  
                PreparedStatement preparedStatement = con.prepareStatement("insert into beneficente(id, nome, data, razao_social, endereco, cnpj, fone, email, info, senha, retira_doacao, doacao_trab) values(?,?,?,?,?,?,?,?,?,?,?,?)");
                preparedStatement.setInt(1, beneficente.getId());
                preparedStatement.setString(2, beneficente.getNome());
                preparedStatement.setString(3, beneficente.getData());
                preparedStatement.setString(4, beneficente.getRazao_social());
                preparedStatement.setString(5, beneficente.getEndereco());
                preparedStatement.setString(6, beneficente.getCnpj());
                preparedStatement.setString(7, beneficente.getFone());
                preparedStatement.setString(8, beneficente.getEmail());
                preparedStatement.setString(9, beneficente.getInfo_entidade());
                preparedStatement.setString(10, beneficente.getSenha());
                preparedStatement.setString(11, beneficente.getRetira_doacao());
                preparedStatement.setString(12, beneficente.getAceita_voluntario());
                
                preparedStatement.execute();
                return true;
          } catch (SQLException ex) {
                Logger lgr = Logger.getLogger(IncluirEntidade.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
                return false;
            }
        }
        
         //lista todos os usuarios cadastrados no banco de dados
     public List<CadastroBeneficente> listBeneficente() {
  
          ArrayList<CadastroBeneficente> lista = new ArrayList<CadastroBeneficente>();
  
          Statement st = null;
          ResultSet rs = null;
  
          try {
                st = con.createStatement();
                String sql = "select * from beneficente ";
               rs = st.executeQuery(sql);
  
                while (rs.next()) {
  
                     CadastroBeneficente cadBeneficente = new CadastroBeneficente();
                     cadBeneficente.setId(rs.getInt(1));
                     cadBeneficente.setNome(rs.getString(2));
                     cadBeneficente.setSenha(rs.getString(3));
                     cadBeneficente.setRazao_social(rs.getString(4));
                     cadBeneficente.setEndereco(rs.getString(5));
                     cadBeneficente.setCnpj(rs.getString(6));
                     cadBeneficente.setFone(rs.getString(7));
                     cadBeneficente.setEmail(rs.getString(8));
                     cadBeneficente.setInfo_entidade(rs.getString(9));
                     cadBeneficente.setSenha(rs.getString(10));
                     cadBeneficente.setRetira_doacao(rs.getString(11));
                     cadBeneficente.setAceita_voluntario(rs.getString(12));
                     

                     lista.add(cadBeneficente);
                }
  
          } catch (SQLException ex) {
                Logger lgr = Logger.getLogger(IncluirEntidade.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
  
          } finally {
                try {
                     if (rs != null) {
                          rs.close();
                     }
                     if (st != null) {
                          st.close();
                     }
                     if (con != null) {
                          con.close();
                     }
  
                } catch (SQLException ex) {
                     Logger lgr = Logger.getLogger(IncluirEntidade.class.getName());
                     lgr.log(Level.WARNING, ex.getMessage(), ex);
                }
          }
          return lista;
     }
}