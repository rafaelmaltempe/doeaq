/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;

import codigos.CadastroProduto;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author rafael
 */
public class IncluirProduto {
 
     Connection con = null;
  
     public IncluirProduto() throws SQLException {
  
          try {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Conectado com sucesso...");
          } catch (ClassNotFoundException e) {
                // TODO Auto-generated catch block
              System.out.println("Problema de conexao: " + e);
                e.printStackTrace();
          }
  
          String url = "jdbc:mysql://localhost:3306/usuario";
          String user = "root";
          String password = "";
          con = DriverManager.getConnection(url, user, password);
     }
  
     public void closeConnection() throws SQLException {
  
          con.close();
     }

        public boolean insertProduto(CadastroProduto cadastro){
          Statement st = null;
          ResultSet rs = null;
  
          try {
                st = con.createStatement();
  
                PreparedStatement preparedStatement = con.prepareStatement("insert into produto(id, descricao, tipo) values(?,?,?)");
                preparedStatement.setInt(1, cadastro.getId());
                preparedStatement.setString(2, cadastro.getDescricao());
                preparedStatement.setString(3, cadastro.getTipo());
  
                preparedStatement.execute();
                return true;
          } catch (SQLException ex) {
                Logger lgr = Logger.getLogger(IncluirProduto.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
                return false;
            }
        }
        
         //lista todos os usuarios cadastrados no banco de dados
     public List<CadastroProduto> listProdutos() {
  
          ArrayList<CadastroProduto> lista = new ArrayList<CadastroProduto>();
  
          Statement st = null;
          ResultSet rs = null;
  
          try {
                st = con.createStatement();
                String sql = "select * from produto ";
               rs = st.executeQuery(sql);
  
                while (rs.next()) {
  
                     CadastroProduto cadProduto = new CadastroProduto();
                     cadProduto.setId(rs.getInt(1));
                     cadProduto.setDescricao(rs.getString(2));
                     cadProduto.setTipo(rs.getString(3));

                     lista.add(cadProduto);
                }
  
          } catch (SQLException ex) {
                Logger lgr = Logger.getLogger(IncluirProduto.class.getName());
                lgr.log(Level.SEVERE, ex.getMessage(), ex);
  
          } finally {
                try {
                     if (rs != null) {
                          rs.close();
                     }
                     if (st != null) {
                          st.close();
                     }
                     if (con != null) {
                          con.close();
                     }
  
                } catch (SQLException ex) {
                     Logger lgr = Logger.getLogger(IncluirProduto.class.getName());
                     lgr.log(Level.WARNING, ex.getMessage(), ex);
                }
          }
          return lista;
     }
}